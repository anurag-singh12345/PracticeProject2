package defaultPackage;
class M {
    void message(){
        System.out.println("This is a message");
    }
}


